#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <dirent.h>
#include <errno.h>
#include <sys/wait.h>
#include <wait.h>
#include <sys/mman.h>
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <ctype.h>
#include <pthread.h>
#include <arpa/inet.h>
#include "sorter_server.h"
char* toSort;
pthread_t *threadArray;
int bIsCategory=1;
int catHeadBool = 0;
int sock;
int sock1;
int sendSock;
int newsockfd3;
char bufferToSendBack[500];
char *IPofClient;
char IPtoSendBack[256];
char secretPortToSendBackBuffer[10];
int portNumber;
int abc= 0;
int catDone = 0;
int secretPort = 97323432;
 int sock2;
struct sockaddr_in serverFin;
pid_t myPID;
pthread_mutex_t a = PTHREAD_MUTEX_INITIALIZER;


int main(int argc, char** argv)
{
  totalProcesses = 1;
  commaPlaceCount = 0;
  fflush(stdout);
  printf("Received Connections from : ");
  fflush(stdout);
  toSort = (char*)malloc(sizeof(char)*500);
  memset(IPtoSendBack,'\0',256);
  char outputPath[2999];
  int firstRun=0;
  root = NULL;
  bIsFirst = 1;
  memset(outputPath,'\0',2999);
  memset(secretPortToSendBackBuffer,'\0',10);
  unsigned int len;
  struct sockaddr_in server,client;
  int newsockfd;
  
  

  if (argc <2)
    {
      // exit(0);
    }
  else if(argv[1][0] =='-' && argv[1][1]=='p'){
    portNumber = atoi(argv[2]);
    if((sock = socket(AF_INET, SOCK_STREAM, 0))==-1){
      perror("socket");
      exit(0);
    }
	  server.sin_family = AF_INET;
	  server.sin_port = htons(portNumber);
	  server.sin_addr.s_addr=INADDR_ANY;
	  bzero(&server.sin_zero, 0);
	  len = sizeof(struct sockaddr_in);
	  socklen_t  clientLength = sizeof(client);
	  if((bind(sock, (struct sockaddr *)&server,len))==-1){
	    perror("bind1");
	    exit(0);

	  }
 	  if((listen(sock,1000))==-1){
	    perror("listen");
	    exit(0);
	  }

	  while(1){


	    if((newsockfd = accept(sock,(struct sockaddr*)&client,&clientLength))==-1){
	      perror("accept");
	      exit(0);
	    }

	    // printf("%d",client.sin_addr.s_addr);
	    //struct sockaddr_in ass;
	     //socklen_t l;
	    //recvfrom(newsockfd,IPtoSendBack,500,0,(struct sockaddr*)&ass,&l);
	    read(newsockfd,IPtoSendBack,500);
	    printf("%s, ",inet_ntoa(client.sin_addr));
	    // printf("%s, ",IPtoSendBack);
	    fflush(stdout);
	    sprintf(secretPortToSendBackBuffer,"%d",secretPort);
	    write(newsockfd,secretPortToSendBackBuffer,10);
	    memset(IPtoSendBack,'\0',500);
	    memset(secretPortToSendBackBuffer,'\0',10);
	    myPID = fork();
	    if(myPID==0){
	      close(newsockfd);
	      //close(sock);
	      break;
	    }else{
	      secretPort++;
	      //printf("%d",secretPort);
	      close(newsockfd);
	    }
  
	  }


	  //exit(0);

	  threadArray =(pthread_t*) malloc(sizeof(pthread_t)*5000);
	  // unsigned int len2;
	  struct sockaddr_in server2; //client2;
	  int newsockfd2;

	 
	  portNumber = secretPort;

	

	    if((sock2 = socket(AF_INET, SOCK_STREAM, 0))==-1){
	      perror("socket");
	      exit(0);
	    }
	    int trueVal=1;
	    setsockopt(sock2,SOL_SOCKET,SO_REUSEADDR,&trueVal,sizeof(trueVal));
	    memset(&server2,0,sizeof(server2));
	    server2.sin_family = AF_INET;
	    
	    server2.sin_port = htons(portNumber);
	    //printf("%d",server.sin_port);
	    server2.sin_addr.s_addr=  INADDR_ANY;         //SO_REUSEADDR;
	    bzero(&server2.sin_zero, 0);
	    // len2 = sizeof(struct sockaddr_in);
	    socklen_t  clientLength2 = sizeof(sock2);
	    if((bind(sock2, (struct sockaddr *)&server2,sizeof(server2)))==-1){
	      perror("bind0");
	      exit(0);
	    }
	    if((listen(sock2,1000))==-1){
	      perror("listen");
	      exit(0);
	    }


	    if((newsockfd2 = accept(sock2,(struct sockaddr*)&sock2,&clientLength2))<0){
	      perror("accept");
	      // exit(0);
	    }

	     
	    if(firstRun ==0){
	      read(newsockfd2, toSort,500);
	      // printf("%s",toSort);
	      // fflush(stdout);
	      firstRun++;
	      //close(newsockfd2);
	      //  close(sock2);
	    }
	    socketHelper(newsockfd2);
	    //  close(newsockfd2);
	    // close(sock2);
	    //sleep(2);

	    while(1){
	      if(abc == 1){
		//	shutdown(sock2,0);
		//	shutdown(newsockfd2,0);
		close(sock2);
		close(newsockfd2);
		break;
	      }
	    }
	  

  }

	








  return 0;
	    
}

void socketHelper(int newsockfd2){
  pthread_mutex_lock(&m);
  struct socketHelper* socketHelper = (struct socketHelper*)malloc(sizeof(socketHelper));
  socketHelper ->newsockfd = malloc(sizeof(int));
  *socketHelper->newsockfd= newsockfd2;
  threadCount++;
  totalThreadCount++;
  threadCountSeeker++;
  pthread_create(&threadArray[threadCount],NULL,sepSock,(void*)socketHelper);
  pthread_mutex_unlock(&m);

}

void *sepSock(void*socketHelper){
  struct socketHelper* indivSocket = (struct socketHelper*)socketHelper;
  newsockfd3 = *indivSocket->newsockfd;
  //printf("%d",newsockfd3);
  char recievingFile[500]="";
  memset(recievingFile,'\0',500);
  while(1){
    recv(newsockfd3, recievingFile,500,0);
    //  write(newsockfd3,"hello bitch",15);
    //printf("->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>%s\n",recievingFile);
    fflush(stdout);
    if(recievingFile[0]=='@'){
      //  threadCountSeeker--;
      continue;
      //  pthread_exit(0);
    }
    
    if(recievingFile[0]=='<'){
      //close(newsockfd3);
      // threadCountSeeker--;


      /* while(threadCountSeeker >0){
	sleep(1);

      }

      int endThreadCounter =0;
      while(endThreadCounter <totalThreadCount-1){
	pthread_join(threadArray[endThreadCounter],NULL);
	endThreadCounter++;
	}*/

      /*
      if((sendSock = socket(AF_INET,SOCK_STREAM,0))==-1){
	perror("sock");
	exit(-1);
      }
      memset(&serverFin,0,sizeof(serverFin));

      serverFin.sin_family = AF_INET;
      serverFin.sin_port = htons(secretPort);
      if(inet_pton(AF_INET,secretPortToSendBackBuffer,&serverFin.sin_addr) <=0)
	{
	  printf("Error, in this inet thing\n");
	  exit(-1);
	}

      if(connect(sendSock,(struct sockaddr *)&serverFin,sizeof(serverFin)) < 0)
	{
	  perror("Connect Has Failed");
	  exit(-1);
	}
      */
       printTree(root,newsockfd3);
      memset(bufferToSendBack,'\0',500);
      strcat(bufferToSendBack,"@");
      write(newsockfd3,bufferToSendBack,500);
      close(newsockfd3);
      close(sock2);
      abc =1;
      pthread_exit(0);
      
    }
    sortingFunc(recievingFile);
    memset(recievingFile,'\0',500);
    
  }
}
void sortingFunc(char * buffer)
{
   
 
  //char buffer[bufferTraverse] = '\0';
  char* ar = (char*) malloc(sizeof(char)*500);
  memset(ar,'\0',sizeof(char)*500);
	
  int c1=0;
  int bquote=0;
  int bspace=0;
  int bTopOfRow = 1;
  int row = 0;
  int avoidSegFaultCommaCount = 0;
  int avoidSegFaultCommaCheck = 0;
  Category* catHead;
  pthread_mutex_lock(&a);
  struct Rows **data = (struct Rows**)malloc(sizeof(struct Rows*)*1);
  if(catHeadBool == 0){
    catHead = (struct Category*) malloc(sizeof(struct Category));
    catHead->next = NULL;
    catHead->catName = (char*)malloc(2 * sizeof(char));
    catHead->itemName = (char*)malloc(2 * 2 * sizeof(char));
    catHeadBool++;
  }
  else{
    catHead = catHead2;
  }
 pthread_mutex_unlock(&a);
  Category *catPtr = catHead;
  Category *pointer = NULL;
	
	

  struct Rows* entry = NULL;
	
  char thisShouldBeAQuote = '\0';
  int bIsEmpty = 0;
  bIsEmpty += 1;
  bIsEmpty -= 1;
  int bufferLength =getMyLength(buffer);
  int bufferTraverse =-1;
  while(++bufferTraverse < bufferLength)
    {
      bIsEmpty = 1;
      if (avoidSegFaultCommaCheck >= avoidSegFaultCommaCount && buffer[bufferTraverse] != '\n' && bIsCategory != 1)
	{
	  //printf("Error: Wrong CSV Format for file: %s\t[%d]\n",fileName,getpid());
	  //exit(totalProcesses);
	}		
		
      if (bIsCategory == 0 && catPtr == catHead && bTopOfRow == 1)
	{
	  //data = (struct Rows**)realloc(data, sizeof(struct Rows*)*(row+1));
	  entry = (struct Rows*)malloc(sizeof(struct Rows));
	  //data[row] = entry;
	  entry->cat = malloc(sizeof(struct Category));
	  pointer = entry->cat;
	  bTopOfRow = 0;
	}
      else if (bIsCategory == 1 && bTopOfRow == 1)
	{
	  //printf("$$$$$$$$$$$\n");
	  bTopOfRow = 0;
	  //struct Rows* entry = 
	  data[0] = (struct Rows*)malloc(sizeof(struct Rows)*1);
	  data[0]->cat = malloc(sizeof(struct Category));
	  pointer = data[0]->cat;
	}	

      if(buffer[bufferTraverse]=='"'&& bquote==0)
	{
	  bquote=1;
	  thisShouldBeAQuote = '"';
	  continue;
	}
      else if (bquote==1 && thisShouldBeAQuote == '"')
	{
	  if(buffer[bufferTraverse] != ' ')
	    {
	      bspace = 1;
	    }
	  ar[c1]=buffer[bufferTraverse];
	  thisShouldBeAQuote = '\0';
	  c1++;
	}
      else if(buffer[bufferTraverse]=='"'&& bquote==1)
	{
	  bquote=0;
	  continue;
	}
      else if((buffer[bufferTraverse]==',' || buffer[bufferTraverse] == '\0' || buffer[bufferTraverse] == '\n') && bquote==0)
	{
	  if (ar[0] == '\0' && bIsCategory == 1)
	    {
	      //printf("Error: Wrong CSV Format\t[%d]\n",getpid());
	      //exit(totalProcesses);
	    }

	  if (buffer[bufferTraverse] == '\n')
	    {
	      ar[c1-1] = '\0';
	      c1 = getMyLength(ar);
				
	      if (bIsCategory == 1)
		{					
		  avoidSegFaultCommaCount++;
		  catPtr->catName = (char *)realloc(catPtr->catName, c1);
		  char *ar2 = malloc((c1+1) * sizeof(char));
		  ar2 = setDuplicate(ar2,ar,c1);
		  ar2[c1] = '\0';
		  catPtr->catName = ar2;
		  catPtr->next = NULL;
		  //iGotYourIP(toSort, catHead);
		  bIsCategory = 0;
		}
	      else
		{
		  //data[row]->cat = malloc(sizeof(struct Category));
		  pointer->catName = malloc(100 * sizeof(char));
		  pointer->itemName = malloc((c1+1) * sizeof(char));
		  char *ar2 = malloc((c1+1) * sizeof(char));
		  ar2 = setDuplicate(ar2,ar,c1);
		  ar2[c1] = '\0';
		  pointer->itemName = ar2;
		  pointer->catName = catPtr->catName;
		  pointer->next = NULL;
		  if(strcmp(entry->cat->next->itemName,"director_name")==0){
		    free(ar);
		    return;
		  }
		  pthread_mutex_lock(&insertionLock);
		  root = insert(root,toSort,entry);
		  pthread_mutex_unlock(&insertionLock);
		  return;
		  row += 1;
		}
	      catPtr = catHead;
	      avoidSegFaultCommaCheck++;
				
	      if (avoidSegFaultCommaCheck < avoidSegFaultCommaCount)
		{
		  //printf("Error: Wrong CSV Format\t[%d]\n",getpid());
		  //exit(totalProcesses);
		}
				
	      memset(ar,'\0',sizeof(char)*500);
	      c1=0;
	      bTopOfRow = 1;
	      bIsCategory = 0;
	      bspace=0;
	      avoidSegFaultCommaCheck = 0;
	      continue;
	    }
	  else if(bspace==1)
	    {
	      if (c1 > 1)
		{
		  if (ar[c1-1] == ' ')
		    {
		      ar[c1-1] = '\0';
		    }
		}
			
	      if (bIsCategory == 1)
		{
		  if (ar[0] == '\0')
		    {
		      //printf("Error: Wrong CSV Format\t[%d]\n",getpid());
		      //exit(totalProcesses);
		    }
		  avoidSegFaultCommaCount++;
		  catPtr->catName = (char *)realloc(catPtr->catName, c1);
		  char *ar2 = malloc((c1+1) * sizeof(char));
		  ar2 = setDuplicate(ar2,ar,c1);
		  ar2[c1] = '\0';
		  catPtr->catName = ar2;
		  catPtr->next = (struct Category*) malloc(sizeof(struct Category));
		  //printf("%d %s",c1,catPtr->catName);
					
		}
	      else
		{
		  pointer->catName = (char *)malloc(100 * sizeof(char));
		  pointer->itemName = (char *)malloc((c1+1) * sizeof(char));
		  char *ar2 = (char *)malloc((c1+1) * sizeof(char));
		  ar2 = setDuplicate(ar2,ar,c1);
		  ar2[c1] = '\0';
		  pointer->itemName = ar2;
		  pointer->catName = catPtr->catName;
		  pointer->next = (struct Category*) malloc(sizeof(struct Category));
		  pointer = pointer->next;
		}
	    }
	  else if (buffer[bufferTraverse] == ',' && c1 == 0) //For empty entries
	    {
	      pointer->catName = (char *)malloc(100 * sizeof(char));
	      pointer->itemName = (char *)malloc(1 * sizeof(char));
	      pointer->itemName = "";
	      pointer->catName = catPtr->catName;
	      pointer->next = (struct Category*) malloc(sizeof(struct Category));
	      pointer = pointer->next;
	    }
			
	  if (catPtr == catHead && bIsCategory == 1)
	    {
	      catHead = catPtr;
	      catPtr = catPtr->next;
	      catHead->next = catPtr;	
	    }
	  else if (bIsCategory == 0)
	    {
	      catPtr = catPtr->next;
	    }
	  else
	    {
	      catPtr = catPtr->next;
	    }
	  avoidSegFaultCommaCheck++;
	  memset(ar,'\0',sizeof(char)*500);
	  c1=0;
	  bspace=0;
	  continue;
	}
      else
	{
	  if(buffer[bufferTraverse] != ' ')
	    {
	      bspace=1;
	      ar[c1]=buffer[bufferTraverse];
	      c1++;
	    }
	  else
	    {
	      int temp = c1 - 1;
	      if (temp >= 0)
		{
		  if (ar[temp] == ' ')
		    {
		      continue;
		    }
		  else
		    {
		      ar[c1]=buffer[bufferTraverse];
		      c1++;
		    }
		}
	      else
		{
		  continue;
		}
	    }
	}
    }

  if (bNeverCat == 0)
    {
      bNeverCat = 1;
      catHead2 = catHead;
    }

  /*if (bIsEmpty == 0)
    {
    //_exit(totalProcesses);
    }*/

   free(ar);
   /* free(data[0]->cat);
  free(data[0]);
  free(data);
  */
  //	fclose(fp);
   //pthread_mutex_unlock(&a);
  return ;
}

//Copies a string to avoid errors for insertion
char* setDuplicate(char* newOne, char* original, int size)
{
  int i;
  for (i = 0; i < size; i++)
    {
      newOne[i] = original[i];
    }
  return newOne;
}

//Prints the final output of the data after sorting
void printSortedData(struct Rows *list,int newsockfd2)
{
  //printf("came into print sorted\n");
  char outgoing[500];
  memset(outgoing,'\0',500);

  Category *p = NULL;

  if (bIsFirst == 1)
    {
      p = catHead2;
      bIsFirst = 0;
      int bIsFirstRow = 1;

      while (p != NULL)
	{
	  if (bIsFirstRow == 1)
	    {
	      int bIsNameWithComma = isNameWithComma(p->catName);
	      if (p->next == NULL)
		{
		  if (bIsNameWithComma == 1)
		    {
		      strcat(outgoing,"\"");
		      strcat(outgoing,p->catName);
		      strcat(outgoing,"\"");

		      //printf("\"1%s\"\n",p->catName);
		    }
		  else
		    {
		      // printf("%s",p->catName);
		      strcat(outgoing,p->catName);
		    }
		  //p = data[0]->cat;
		  bIsFirstRow = 0;
		  //fprintf(newFP,"\n");

		  // *numOfBytes = (unsigned int)(strlen(outgoing)+1);
		  // printf("%u",*numOfBytes);
		  // int temp = strlen(outgoing)+1;
		  //char integer[4];
		  //*((int*)integer)=temp;
		  //  write(sendSock,numOfBytes ,sizeof(numOfBytes));
		  write(newsockfd2,outgoing,500);
		  // numOfBytes=0;



		  // memset(numOfBytes,'\0',15);
		  memset(outgoing,'\0',500);
		  continue;
		}
	      else
		{
		  if (bIsNameWithComma == 1)
		    {
		      strcat(outgoing,"\"");
		      strcat(outgoing,p->catName);
		      strcat(outgoing,"\"");
		      strcat(outgoing,",");
		    }
		  else
		    {
		      strcat(outgoing,p->catName);
		      strcat(outgoing,",");
		    }
		}
	    }
	  p = p->next;
	}
    }

  if (bIsFirst == 0)
    {
      //printf("Writing the non-category entries\n");
      //fprintf(newFP,"\n");
      p = list->cat;
      while (p != NULL)
	{
	  int bIsNameWithComma = isNameWithComma(p->itemName);
	  if (p->next == NULL)
	    {
	      if (bIsNameWithComma == 1)
		{
		  strcat(outgoing,"\"");
		  strcat(outgoing,p->itemName);
		  strcat(outgoing,"\"");
		  //printf("\"2%s\"\n",p->itemName);
		}
	      else
		{
		  strcat(outgoing,p->itemName);
		  //printf("\"3%s\"\n",p->itemName);
		}
	      //p = data[0]->cat;
	      //bIsFirstRow = 0;
	      //fprintf(newFP,"\n");
	      //continue;
	    }
	  else
	    {
	      if (bIsNameWithComma == 1)
		{
		  strcat(outgoing,"\"");
		  strcat(outgoing,p->itemName);
		  strcat(outgoing,"\"");
		  strcat(outgoing,",");
		  //printf("\"4%s\"\n",p->itemName);
		}
	      else
		{
		  strcat(outgoing,p->itemName);
		  strcat(outgoing,",");
		  //printf("\"5%s\"\n",p->itemName);
		}
	    }

	  p = p->next;
	}
    }
  // printf("%s\n",outgoing);
  //*numOfBytes = (unsigned int)(strlen(outgoing)+1);
    //write(sendSock,numOfBytes,sizeof(numOfBytes));
  write(newsockfd2,outgoing,500);
  //*numOfBytes=0;
  //memset(numOfBytes,'\0',15);
}

int isNameWithComma(char *stringToSearch)
{
  int i = 0;
  while (stringToSearch[i] != '\0')
    {
      if (stringToSearch[i] == ',')
	{
	  return 1;
	}
      i++;
    }
  return 0;
}


//Checks if the user-entered category to sort by is a category in the CSV file
void iGotYourIP(char *toSort, struct Category *traveler)
{
  int areWeGood = 0;
  const char *holdString = traveler->catName;

  while (traveler != NULL)
    {
      holdString = traveler->catName;
      if (strcasecmp(holdString,toSort) == 0)
	{
	  areWeGood = 1;
	  break;
	}
      traveler = traveler->next;
    }

  if (areWeGood == 1)
    {
      //printf("\n%s\n",holdString);
      return;
    }

  pthread_exit(0);
  /*else
    {
    }*/
}

//Recursively travels through directory of files
void traverseDirectory(char *buffer, char* toSort, int threadsSpinned)
{
  /*DIR *directoryPtr;
    struct dirent *buffer[bufferTraverse];
    pthread_t *TID_I_O = (pthread_t*)malloc(sizeof(pthread_t)*1);

    if ((directoryPtr = opendir(buffer[bufferTraverse]Item)) == NULL)
    {
    //printf("Directory not found\t\n");
    return;
    }

    while ((buffer[bufferTraverse] = readdir(directoryPtr)) != NULL)
    {
    if (buffer[bufferTraverse]->d_type == DT_DIR) 
    {
    if (strcmp(buffer[bufferTraverse]->d_name, ".") == 0 || strcmp(buffer[bufferTraverse]->d_name, "..") == 0)
    {
    continue;
    }

    int buffer[bufferTraverse]Len = getMyLength(buffer[bufferTraverse]->d_name);

    if (buffer[bufferTraverse]Len > 1)
    {
    if (buffer[bufferTraverse]->d_name[0] == '.' && buffer[bufferTraverse]->d_name[1] != '/')
    {
    continue;
    }
    }

    totalProcesses++;
    //--------------------------->>>>>>>>printf("Folder Fork on ---> %s\t\n",buffer[bufferTraverse]->d_name);
    pthread_t myTID; //= pthread_self();
    //printf("Folder Name: %s\t[%d]\n",entry->d_name,getpid());
    char toConcat[2999];
    strcpy(toConcat,buffer[bufferTraverse]Item);
			
    if(checkIfSlash(buffer[bufferTraverse]Item) == 1)
    {
    strncat(toConcat,buffer[bufferTraverse]->d_name,buffer[bufferTraverse]Len+1);
    threadsSpinned++;
				
    TID_I_O = (pthread_t*)realloc(TID_I_O,sizeof(pthread_t)*threadsSpinned);

    hubData *threadHub1 = (struct hubData*)malloc(sizeof(struct hubData));
    int conCatLen = getMyLength(toConcat);
    threadHub1->name=malloc(sizeof(char)*(conCatLen+1));
    threadHub1->name=setDuplicate(threadHub1->name, toConcat,conCatLen);
    threadHub1->toSort=toSort;
    threadHub1->sortname=NULL;
    threadHub1->sorttoSort=NULL;
    threadHub1->sortbuffer[bufferTraverse]Item=NULL;
    threadHub1->functiontype=malloc(sizeof(int));//if default:0 traverseDirec:1 sortingFunc:2
    *threadHub1->functiontype=1;	
    pthread_create(&myTID, NULL, hubCenter, threadHub1);

    TID_I_O[threadsSpinned-1] = myTID;
    }
    else
    {
    strncat(toConcat,"/",2);
    strncat(toConcat,buffer[bufferTraverse]->d_name,buffer[bufferTraverse]Len+1);
    threadsSpinned++;
    TID_I_O = (pthread_t*)realloc(TID_I_O,sizeof(pthread_t)*threadsSpinned);
    hubData *threadHub2 = (struct hubData*)malloc(sizeof(struct hubData));
    int conCatLen = getMyLength(toConcat);
    threadHub2->name=malloc(sizeof(char)*(conCatLen+1));
    threadHub2->name=setDuplicate(threadHub2->name, toConcat,conCatLen+1);
    threadHub2->toSort=toSort;
    threadHub2->sortname=NULL;
    threadHub2->sorttoSort=NULL;
    threadHub2->sortbuffer[bufferTraverse]Item=NULL;
    threadHub2->functiontype=malloc(sizeof(int));
    *threadHub2->functiontype=1;//if default:0 traverseDirec:1 sortingFunc:2
    pthread_create(&myTID, NULL, hubCenter, threadHub2);

    TID_I_O[threadsSpinned-1] = myTID;
    }
    } 
    else
    {
    //printf("File Name: %s\n",buffer[bufferTraverse]->d_name);
    if (checkIfCSV(buffer[bufferTraverse]->d_name) == 1)
    {
    if(checkIfAlreadySorted(buffer[bufferTraverse]->d_name)	== 0)
    {
    totalProcesses++;
    //printf("File Fork on ---> %s\t\n",buffer[bufferTraverse]->d_name);
    pthread_t myTID;// = pthread_self();
    threadsSpinned++;
    TID_I_O = (pthread_t*)realloc(TID_I_O,sizeof(pthread_t)*threadsSpinned);
    hubData *threadHub3= (struct hubData*)malloc(sizeof(struct hubData));
    threadHub3->name=NULL;
    threadHub3->toSort=NULL;
    int sortnameLen = getMyLength(buffer[bufferTraverse]->d_name);
    threadHub3->sortname=malloc(sizeof(char)*(sortnameLen+1));
    threadHub3->sortname=setDuplicate(threadHub3->sortname,buffer[bufferTraverse]->d_name,sortnameLen+1);
    threadHub3->sorttoSort=toSort;
    int buffer[bufferTraverse]ItemLen = getMyLength(buffer[bufferTraverse]Item);
    threadHub3->sortbuffer[bufferTraverse]Item=malloc(sizeof(char)*(buffer[bufferTraverse]ItemLen+1));
    threadHub3->sortbuffer[bufferTraverse]Item=setDuplicate(threadHub3->sortbuffer[bufferTraverse]Item,buffer[bufferTraverse]Item,buffer[bufferTraverse]ItemLen+1);
    threadHub3->functiontype=malloc(sizeof(int));
    *threadHub3->functiontype=2;//if default:0 traverseDirec:1 sortingFunc:2
    pthread_create(&myTID, NULL, hubCenter, threadHub3);
    TID_I_O[threadsSpinned-1] = myTID;
					
    }
    else
    {
    //printf("Nope, I am not going to sort %s again!\n",buffer[bufferTraverse]->d_name);
    }
    }
    }
    }

    if (threadsSpinned >= 1)
    {
    int a = 0;
    while (a < threadsSpinned)
    {
    pthread_join(TID_I_O[a], NULL);
    a++;
    }
    }

    free(TID_I_O);

    closedir(directoryPtr);*/
}

//Checks to see if the buffer[bufferTraverse]ent pathway has a slash or not
int checkIfSlash(char *name)
{
  int len = getMyLength(name);

  if (name[len-1] == '/')
    {
      return 1;
    }
  else
    {
      return 0;
    }
}

int checkIfCSV(char *fileName)
{
  int len = getMyLength(fileName);

  if (fileName[len-4] == '.' && (fileName[len-3] == 'c' || fileName[len-3] == 'C') && (fileName[len-2] == 's' || fileName[len-2] == 'S') && (fileName[len-1] == 'v' || fileName[len-1] == 'V'))
    {
      return 1;
    }
  else
    {
      return 0;
    }
}

int checkIfAlreadySorted(char *fileName)
{
  char *alSorted = "-sorted";
  int lenf = getMyLength(fileName);
  int lene = getMyLength(alSorted);
  int i = 0;
  int j = 0;

  for (i = 0; i < lenf; i++)
    {
      if (fileName[i] == alSorted[0])
	{
	  for (j=0; j < lene; j++)
	    {
	      if (fileName[i+j] == alSorted[j])
		{
		  if (j+1 == lene)
		    {
		      return 1;
		    }
		  continue;
		}
	      else
		{
		  break;
		}
	    }
	}
    }
	
  return 0;
}

//Travels the row's link list to the category that we want to compare
char *catTravel(const char* catToSort, struct Category *traveler)
{
  const char *holdString = traveler->catName;

  while (strcasecmp(holdString,catToSort) != 0)
    {
      if (traveler->next != NULL)
	{
	  traveler = traveler->next;
	  holdString = traveler->catName;
	}
    }

  return traveler->itemName;
}

//Recursively travels through Binary Search Tree and 
Node* insert(Node *start, char *toSort, struct Rows* entry)
{
  struct Node *temp;
  char *tempCati = NULL;
  char *tempCatj = NULL;

  if(start==NULL)
    {
      //printf("----END----\n");
      //pthread_mutex_lock(&insertionLock);
      temp=(struct Node*) malloc(sizeof(struct Node));
      temp->list = entry;
      temp->bIsSeen = 0;
      temp->left=NULL;
      temp->right=NULL;
      //pthread_mutex_unlock(&insertionLock);
	      
      //printf("%s\n",temp->list->cat->next->itemName);
      return temp;

    }

  tempCati = catTravel(toSort,start->list->cat);
  tempCatj = catTravel(toSort,entry->cat);
  //printf("1: %s\t2: %s\n",tempCati,tempCatj);

  if (strcasecmp(tempCatj,tempCati) < 0)
    {
      //printf("I--LEFT\n");
      start->left=insert(start->left,toSort,entry);
    }
  else if (strcasecmp(tempCatj,tempCati) > 0)
    {
      //printf("I--RIGHT\n");
      start->right=insert(start->right,toSort,entry);
    }
  else
    {
      //printf("I--RIGHT(DUPLICATE)\n");
      start->right=insert(start->right,toSort,entry);
    }
  return start;
}

void printTree(Node *start,int newsockfd2)
{//printf("printing tree...\n");
	
  if (start == NULL)
    {
      //printf("What if...\n");
      return;
    }

  if (start->left == NULL)
    {
      if (start->bIsSeen == 0)
	{
	  //printf("PRINT\n");
	  printSortedData(start->list, newsockfd2);
	  start->bIsSeen = 1;
	}
    }

  if (start->left != NULL)
    {
      //printf("LEFT\n");
      printTree(start->left,newsockfd2);

      if (start->left->bIsSeen == 1)
	{
	  if (start->bIsSeen == 0)
	    {
	      //printf("PRINT?\n");
	      printSortedData(start->list,newsockfd2);
	      start->bIsSeen = 1;
	    }
	}
    }
	
  if (start->right != NULL)
    {
      //printf("RIGHT\n");
      printTree(start->right,newsockfd2);
    }

  //printf("UP\n");
  return;
}

//Copies contents of one char array into another
char *fillItUp(char *oldStr)
{
  char newChar[2999];
  memset(newChar,'\0',2999);
  int len = getMyLength(oldStr);
  int i = 0;

  for (i = 0; i < len; i++)
    {
      newChar[i] = oldStr[i];
    }

  char *newStr = newChar;

  return newStr;
}

int getMyLength(char *dontSegFaultMe)
{
  char *dontSegFaultMe2 = dontSegFaultMe;
	
  while (*dontSegFaultMe != '\0')
    {
      dontSegFaultMe++;		
    }
  return dontSegFaultMe - dontSegFaultMe2;
}

//the function that will route the threads to whatever function call they needed to make, for all your threading needs
void * hubCenter(void *hubb)
{
  /*	hubData *key=hubb;
	printf("%lu,",pthread_self());
	int func = *key->functiontype;
	//free(key->functiontype);
	//fflush(stdout);

	switch(func)
	{
	case 1:
	{
	int nameLen = getMyLength(key->name);
	int sortLen = getMyLength(key->toSort);
	char *name=malloc(sizeof(char)*(nameLen+1));
	char *sort=malloc(sizeof(char)*(sortLen+1));
	name=setDuplicate(name,key->name,nameLen);
	sort=setDuplicate(sort,key->toSort,sortLen);
	traverseDirectory(name,sort,0);
	free(sort);
	free(name);
	free(key->functiontype);
	free(key->name);
	free(hubb);
	pthread_exit(0);
	break;
	}
	case 2:
	{
	int sortnameLen = getMyLength(key->sortname);
	int sorttoSortLen = getMyLength(key->sorttoSort);
	int sortbuffer[bufferTraverse]ItemLen = getMyLength(key->sortbuffer[bufferTraverse]Item);
	char *sortname=malloc(sizeof(char)*(sortnameLen+1));
	char *sorttoSort=malloc(sizeof(char)*(sorttoSortLen+1));
	char *sortbuffer[bufferTraverse]Item=malloc(sizeof(char)*(sortbuffer[bufferTraverse]ItemLen+1));
	sortname=setDuplicate(sortname,key->sortname,sortnameLen);
	sorttoSort=setDuplicate(sorttoSort,key->sorttoSort,sorttoSortLen);
	sortbuffer[bufferTraverse]Item=setDuplicate(sortbuffer[bufferTraverse]Item,key->sortbuffer[bufferTraverse]Item,sortbuffer[bufferTraverse]ItemLen);
	sortingFunc(sortname,sorttoSort,sortbuffer[bufferTraverse]Item);
	free(sortbuffer[bufferTraverse]Item);
	free(sorttoSort);
	free(sortname);
	free(key->functiontype);
	free(key->sortbuffer[bufferTraverse]Item);
	free(key->sortname);
	free(hubb);
	pthread_exit(0);
	break;
	}
	}*/
  return 0;	 
}
